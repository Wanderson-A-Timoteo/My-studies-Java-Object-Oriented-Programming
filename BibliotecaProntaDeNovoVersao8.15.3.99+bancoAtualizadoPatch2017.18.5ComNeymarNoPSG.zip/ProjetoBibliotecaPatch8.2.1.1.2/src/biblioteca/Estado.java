package biblioteca;

/**
 *
 * @author PEDROHENRIQUE
 */
public enum Estado {
    insercao, edicao, visualizacao;
}
