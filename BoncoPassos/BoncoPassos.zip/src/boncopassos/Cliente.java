/*
AULA 03
A classe Cliente terá os seguintes atributos: 
    nome, cpf, telefone e endereço.
*/
package boncopassos;

public class Cliente {
    String nome, endereco;
    long cpf, fone;
    
}
